// Curated offline English-Indonesian & English-English dictionary dataset
const OFFLINE_DICTIONARY = [
  {
    word: "algorithm",
    phonetic: "/ˈæl.ɡə.rɪ.ðəm/",
    category: "Teknologi",
    indonesian: "Algoritma; urutan langkah logis untuk menyelesaikan suatu masalah.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A process or set of rules to be followed in calculations or other problem-solving operations, especially by a computer.",
            example: "The search engine uses a complex algorithm to rank web pages."
          }
        ]
      }
    ],
    synonyms: ["procedure", "formula", "computation"],
    antonyms: []
  },
  {
    word: "serendipity",
    phonetic: "/ˌser.ənˈdɪp.ə.ti/",
    category: "Umum",
    indonesian: "Keberuntungan menemukan sesuatu yang berharga secara tidak sengaja.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The occurrence and development of events by chance in a happy or beneficial way.",
            example: "Meeting my co-founder at a small coffee shop was pure serendipity."
          }
        ]
      }
    ],
    synonyms: ["fortune", "luck", "chance"],
    antonyms: ["misfortune", "calamity"]
  },
  {
    word: "ephemeral",
    phonetic: "/ɪˈfem.ər.əl/",
    category: "Akademik",
    indonesian: "Bersifat sementara; berlangsung sangat singkat.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Lasting for a very short time.",
            example: "Fashions are ephemeral, changing with every new season."
          }
        ]
      }
    ],
    synonyms: ["transient", "fleeting", "temporary"],
    antonyms: ["permanent", "eternal", "enduring"]
  },
  {
    word: "resilient",
    phonetic: "/rɪˈzɪl.jənt/",
    category: "Umum",
    indonesian: "Tangguh; mampu bangkit kembali dengan cepat dari kesulitan.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Able to withstand or recover quickly from difficult conditions.",
            example: "A resilient distributed system continues operating even when a node fails."
          }
        ]
      }
    ],
    synonyms: ["tough", "adaptable", "robust"],
    antonyms: ["fragile", "vulnerable"]
  },
  {
    word: "paradigm",
    phonetic: "/ˈpær.ə.daɪm/",
    category: "Akademik",
    indonesian: "Paradigma; kerangka berpikir atau pola acuan utama.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A typical example or pattern of something; a distinct set of concepts or thought patterns.",
            example: "Object-oriented programming introduced a new paradigm in software engineering."
          }
        ]
      }
    ],
    synonyms: ["model", "framework", "pattern"],
    antonyms: []
  },
  {
    word: "eloquent",
    phonetic: "/ˈel.ə.kwənt/",
    category: "Umum",
    indonesian: "Fasih; mampu menyampaikan gagasan dengan kata-kata yang indah dan meyakinkan.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Fluent or persuasive in speaking or writing.",
            example: "She gave an eloquent presentation about ethical artificial intelligence."
          }
        ]
      }
    ],
    synonyms: ["articulate", "fluent", "expressive"],
    antonyms: ["inarticulate", "hesitant"]
  },
  {
    word: "abstraction",
    phonetic: "/æbˈstræk.ʃən/",
    category: "Teknologi",
    indonesian: "Abstraksi; penyederhanaan sistem kompleks dengan menyembunyikan detail teknis.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The process of hiding implementation details and showing only essential features of an object or system.",
            example: "APIs provide a clean level of abstraction over raw database queries."
          }
        ]
      }
    ],
    synonyms: ["generalization", "conceptualization"],
    antonyms: ["implementation", "concreteness"]
  },
  {
    word: "asynchronous",
    phonetic: "/eɪˈsɪŋ.krə.nəs/",
    category: "Teknologi",
    indonesian: "Asinkron; berjalan secara tidak bersamaan tanpa saling menunggu.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Not existing or occurring at the same time; allowing tasks to run independently of the main program flow.",
            example: "JavaScript uses asynchronous callbacks and promises to fetch data without freezing the UI."
          }
        ]
      }
    ],
    synonyms: ["non-blocking", "concurrent"],
    antonyms: ["synchronous", "sequential"]
  },
  {
    word: "compiler",
    phonetic: "/kəmˈpaɪ.lər/",
    category: "Teknologi",
    indonesian: "Kompilator; program yang menerjemahkan kode sumber menjadi kode mesin.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A program that converts instructions into a machine-code or lower-level form so that they can be read and executed by a computer.",
            example: "The compiler reported a syntax error on line 42."
          }
        ]
      }
    ],
    synonyms: ["translator"],
    antonyms: ["interpreter"]
  },
  {
    word: "database",
    phonetic: "/ˈdeɪ.tə.beɪs/",
    category: "Teknologi",
    indonesian: "Basis data; kumpulan data terstruktur yang disimpan secara elektronik.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A structured set of data held in a computer, especially one that is accessible in various ways.",
            example: "All user profiles are securely stored in a relational database."
          }
        ]
      }
    ],
    synonyms: ["repository", "datastore", "archive"],
    antonyms: []
  },
  {
    word: "debugging",
    phonetic: "/diːˈbʌɡ.ɪŋ/",
    category: "Teknologi",
    indonesian: "Proses mencari dan memperbaiki kesalahan (bug) pada program komputer.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The process of identifying and removing errors from computer hardware or software.",
            example: "Careful debugging saved the team hours of troubleshooting in production."
          }
        ]
      }
    ],
    synonyms: ["troubleshooting", "diagnosis"],
    antonyms: []
  },
  {
    word: "encryption",
    phonetic: "/ɪnˈkrɪp.ʃən/",
    category: "Teknologi",
    indonesian: "Enkripsi; proses mengubah data menjadi kode rahasia agar aman.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The process of converting information or data into a code, especially to prevent unauthorized access.",
            example: "End-to-end encryption ensures only the sender and recipient can read the messages."
          }
        ]
      }
    ],
    synonyms: ["ciphering", "encoding"],
    antonyms: ["decryption"]
  },
  {
    word: "framework",
    phonetic: "/ˈfreɪm.wɜːk/",
    category: "Teknologi",
    indonesian: "Kerangka kerja; struktur dasar untuk membangun aplikasi perangkat lunak.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A basic structure underlying a system, concept, or text; a reusable software platform for developing applications.",
            example: "Choosing the right web framework can accelerate project delivery."
          }
        ]
      }
    ],
    synonyms: ["architecture", "infrastructure", "scaffold"],
    antonyms: []
  },
  {
    word: "heuristic",
    phonetic: "/hjʊəˈrɪs.tɪk/",
    category: "Teknologi",
    indonesian: "Heuristik; pendekatan praktis untuk menemukan solusi cepat yang cukup optimal.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Enabling a person to discover or learn something for themselves; using practical rules of thumb.",
            example: "The A* pathfinding algorithm uses a heuristic function to estimate distance."
          }
        ]
      }
    ],
    synonyms: ["exploratory", "empirical"],
    antonyms: ["exhaustive"]
  },
  {
    word: "interface",
    phonetic: "/ˈɪn.tə.feɪs/",
    category: "Teknologi",
    indonesian: "Antarmuka; titik interaksi antara pengguna dengan sistem atau antar komponen.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A point where two systems, subjects, or organizations meet and interact.",
            example: "A clean user interface makes complex software feel effortless."
          }
        ]
      },
      {
        partOfSpeech: "verb",
        definitions: [
          {
            definition: "To interact or connect with another system or person.",
            example: "The mobile app interfaces with the cloud server via REST."
          }
        ]
      }
    ],
    synonyms: ["boundary", "portal", "UI"],
    antonyms: []
  },
  {
    word: "latency",
    phonetic: "/ˈleɪ.tən.si/",
    category: "Teknologi",
    indonesian: "Latensi; jeda waktu antara permintaan dikirim dan respons diterima.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The delay before a transfer of data begins following an instruction for its transfer.",
            example: "Caching static assets near users significantly reduces network latency."
          }
        ]
      }
    ],
    synonyms: ["delay", "lag"],
    antonyms: ["immediacy"]
  },
  {
    word: "recursion",
    phonetic: "/rɪˈkɜː.ʃən/",
    category: "Teknologi",
    indonesian: "Rekursi; teknik pemrograman di mana sebuah fungsi memanggil dirinya sendiri.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The repeated application of a recursive procedure or definition, where a function calls itself.",
            example: "Tree traversal is often written elegantly using recursion."
          }
        ]
      }
    ],
    synonyms: ["self-reference", "iteration"],
    antonyms: []
  },
  {
    word: "scalability",
    phonetic: "/ˌskeɪ.ləˈbɪl.ə.ti/",
    category: "Teknologi",
    indonesian: "Skalabilitas; kemampuan sistem menangani peningkatan beban kerja secara efisien.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The capacity to be changed in size or scale to handle growing amounts of work.",
            example: "Microservices architecture is often adopted to improve system scalability."
          }
        ]
      }
    ],
    synonyms: ["extensibility", "expandability"],
    antonyms: ["rigidity"]
  },
  {
    word: "ambiguous",
    phonetic: "/æmˈbɪɡ.ju.əs/",
    category: "Akademik",
    indonesian: "Ambigu; memiliki lebih dari satu makna atau tidak jelas.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Open to more than one interpretation; not having one obvious meaning.",
            example: "Requirements should never be ambiguous before development begins."
          }
        ]
      }
    ],
    synonyms: ["vague", "unclear", "equivocal"],
    antonyms: ["explicit", "unambiguous", "clear"]
  },
  {
    word: "coherent",
    phonetic: "/kəʊˈhɪə.rənt/",
    category: "Akademik",
    indonesian: "Koheren; logis, terstruktur, dan saling berkaitan dengan baik.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Logical and consistent; forming a unified whole.",
            example: "The thesis presented a coherent argument supported by empirical data."
          }
        ]
      }
    ],
    synonyms: ["logical", "consistent", "unified"],
    antonyms: ["incoherent", "disjointed"]
  },
  {
    word: "empirical",
    phonetic: "/ɪmˈpɪr.ɪ.kəl/",
    category: "Akademik",
    indonesian: "Empiris; berdasarkan pengamatan nyata atau eksperimen, bukan teori semata.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Based on, concerned with, or verifiable by observation or experience rather than theory or pure logic.",
            example: "The researchers gathered empirical evidence from over 500 participants."
          }
        ]
      }
    ],
    synonyms: ["observed", "experimental", "practical"],
    antonyms: ["theoretical", "hypothetical"]
  },
  {
    word: "hypothesis",
    phonetic: "/haɪˈpɒθ.ə.sɪs/",
    category: "Akademik",
    indonesian: "Hipotesis; dugaan sementara yang perlu diuji kebenarannya melalui riset.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "A supposition or proposed explanation made on the basis of limited evidence as a starting point for further investigation.",
            example: "We ran A/B tests to validate our hypothesis about user engagement."
          }
        ]
      }
    ],
    synonyms: ["theory", "assumption", "premise"],
    antonyms: ["fact", "certainty"]
  },
  {
    word: "innovative",
    phonetic: "/ˈɪn.ə.və.tɪv/",
    category: "Akademik",
    indonesian: "Inovatif; menghadirkan gagasan atau metode baru yang kreatif.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Featuring new methods; advanced and original.",
            example: "The students built an innovative mobile app for sign language translation."
          }
        ]
      }
    ],
    synonyms: ["original", "creative", "pioneering"],
    antonyms: ["conventional", "traditional"]
  },
  {
    word: "pragmatic",
    phonetic: "/præɡˈmæt.ɪk/",
    category: "Akademik",
    indonesian: "Pragmatis; berfokus pada hasil praktis dan realistis.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Dealing with things sensibly and realistically in a way that is based on practical rather than theoretical considerations.",
            example: "Taking a pragmatic approach helped the team ship the product on time."
          }
        ]
      }
    ],
    synonyms: ["practical", "realistic", "sensible"],
    antonyms: ["idealistic", "impractical"]
  },
  {
    word: "synthesis",
    phonetic: "/ˈsɪn.θə.sɪs/",
    category: "Akademik",
    indonesian: "Sintesis; penggabungan berbagai unsur menjadi satu kesatuan yang utuh.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The combination of ideas or components to form a theory or system.",
            example: "Her paper is a brilliant synthesis of cognitive science and machine learning."
          }
        ]
      }
    ],
    synonyms: ["combination", "integration", "fusion"],
    antonyms: ["analysis", "separation"]
  },
  {
    word: "ubiquitous",
    phonetic: "/juːˈbɪk.wɪ.təs/",
    category: "Akademik",
    indonesian: "Ada di mana-mana; sangat umum dijumpai pada waktu bersamaan.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Present, appearing, or found everywhere.",
            example: "Smartphones have become ubiquitous in modern daily life."
          }
        ]
      }
    ],
    synonyms: ["omnipresent", "pervasive", "universal"],
    antonyms: ["rare", "scarce"]
  },
  {
    word: "benevolent",
    phonetic: "/bəˈnev.əl.ənt/",
    category: "Umum",
    indonesian: "Baik hati; dermawan dan suka menolong sesama.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Well meaning and kindly.",
            example: "A benevolent mentor always encourages students to ask questions."
          }
        ]
      }
    ],
    synonyms: ["kind", "compassionate", "generous"],
    antonyms: ["malevolent", "cruel"]
  },
  {
    word: "diligent",
    phonetic: "/ˈdɪl.ɪ.dʒənt/",
    category: "Umum",
    indonesian: "Rajin; tekun dan teliti dalam mengerjakan sesuatu.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Having or showing care and conscientiousness in one's work or duties.",
            example: "Diligent practice is the key to mastering any programming language."
          }
        ]
      }
    ],
    synonyms: ["industrious", "hardworking", "meticulous"],
    antonyms: ["lazy", "negligent"]
  },
  {
    word: "gratitude",
    phonetic: "/ˈɡræt.ɪ.tʃuːd/",
    category: "Umum",
    indonesian: "Rasa syukur; ungkapan terima kasih atas kebaikan yang diterima.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The quality of being thankful; readiness to show appreciation for and to return kindness.",
            example: "He expressed deep gratitude to his lecturers and teammates."
          }
        ]
      }
    ],
    synonyms: ["thankfulness", "appreciation"],
    antonyms: ["ingratitude"]
  },
  {
    word: "harmony",
    phonetic: "/ˈhɑː.mə.ni/",
    category: "Umum",
    indonesian: "Harmoni; keselarasan dan keseimbangan yang indah.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The quality of forming a pleasing and consistent whole; agreement or concord.",
            example: "Good UI design balances typography, spacing, and color in harmony."
          }
        ]
      }
    ],
    synonyms: ["balance", "concord", "unity"],
    antonyms: ["discord", "conflict"]
  },
  {
    word: "lucid",
    phonetic: "/ˈluː.sɪd/",
    category: "Umum",
    indonesian: "Jernih; mudah dipahami dan jelas.",
    meanings: [
      {
        partOfSpeech: "adjective",
        definitions: [
          {
            definition: "Expressed clearly; easy to understand.",
            example: "The documentation provides a lucid explanation of every API endpoint."
          }
        ]
      }
    ],
    synonyms: ["clear", "intelligible", "transparent"],
    antonyms: ["obscure", "confusing"]
  },
  {
    word: "zenith",
    phonetic: "/ˈzen.ɪθ/",
    category: "Umum",
    indonesian: "Puncak; titik tertinggi dari pencapaian atau keberhasilan.",
    meanings: [
      {
        partOfSpeech: "noun",
        definitions: [
          {
            definition: "The time at which something is most powerful or successful.",
            example: "The band reached the zenith of its popularity in the late 1990s."
          }
        ]
      }
    ],
    synonyms: ["peak", "pinnacle", "apex"],
    antonyms: ["nadir", "bottom"]
  }
];
