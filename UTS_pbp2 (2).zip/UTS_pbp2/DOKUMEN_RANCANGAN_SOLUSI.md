# Dokumen Rancangan Solusi & Arsitektur Sistem
## Aplikasi Kamus Besar Bahasa Inggris Multi-Platform (**LexiGo**)

- **Mata Kuliah:** Pemrograman Berbasis Platform 2
- **Program Studi:** Informatika
- **Dosen Pengampu:** Untung Subagyo, M.Kom.
- **Mahasiswa:** Ammar (NIM: `12231944`)
- **Jenis Tugas:** Ujian Tengah Semester (UTS) — *Solution & Architecture Review*

---

## 1. Analisis Permasalahan

### 1.1 Latar Belakang
Mahasiswa Informatika dan pembelajar bahasa Inggris sering membutuhkan kamus yang cepat, akurat, dan memuat kosakata teknis (seperti *algorithm*, *abstraction*, *asynchronous*, *heuristic*) maupun kosakata akademik dan umum. Aplikasi kamus konvensional sering kali terlalu berat, penuh iklan, tidak memiliki konteks istilah Informatika, atau tidak dapat digunakan ketika koneksi internet tidak stabil.

### 1.2 Identifikasi Pengguna & Kebutuhan
- **Mahasiswa / Pelajar (khususnya Informatika):** Membutuhkan pencarian cepat istilah teknis & akademik beserta padanan Bahasa Indonesia, transkripsi fonetik IPA, dan pelafalan suara.
- **Pengguna Umum (Web & Mobile):** Membutuhkan antarmuka yang bersih, nyaman dibaca (*light/dark mode*), dapat diakses di laptop maupun ponsel Android tanpa harus menginstal aplikasi berukuran besar.

### 1.3 Tujuan Pengembangan
1. Membangun aplikasi kamus Bahasa Inggris–Indonesia & Inggris–Inggris yang cepat dengan pendekatan **Offline-First + Online API Fallback**.
2. Menghadirkan pengalaman **Multi-Platform** (Web Desktop & Mobile/Android melalui *Progressive Web App* / PWA) dari satu basis kode (*single codebase*).
3. Menyediakan fitur pelafalan audio (*Web Speech API*), penyimpanan kata favorit, dan riwayat pencarian secara persisten.

### 1.4 Batasan & Ruang Lingkup Solusi
- Dataset offline mencakup kosakata terkurasi kategori *Teknologi*, *Akademik*, dan *Umum* dengan terjemahan Bahasa Indonesia.
- Untuk kata di luar dataset offline, aplikasi mengambil definisi Bahasa Inggris dari REST API publik (`api.dictionaryapi.dev`) saat perangkat terhubung internet.
- Penyimpanan favorit dan riwayat dilakukan secara lokal di perangkat (*client-side persistence* via `localStorage`) tanpa memerlukan autentikasi server.

---

## 2. Analisis Kebutuhan Sistem

### 2.1 Kebutuhan Fungsional (Functional Requirements)
| Kode | Kebutuhan Fungsional | Prioritas |
|------|----------------------|-----------|
| FR-01 | Pencarian kata Bahasa Inggris dengan *instant autocomplete* | Tinggi (P1) |
| FR-02 | Menampilkan arti Bahasa Indonesia, definisi Bahasa Inggris, contoh kalimat, kelas kata (*part of speech*), dan fonetik IPA | Tinggi (P1) |
| FR-03 | Fallback otomatis ke REST API eksternal jika kata tidak ada di kamus offline | Tinggi (P1) |
| FR-04 | Pelafalan audio kata Bahasa Inggris (Audio URL / *Web Speech API*) | Sedang (P2) |
| FR-05 | Menyimpan dan mengelola daftar kata **Favorit** serta **Riwayat Pencarian** | Sedang (P2) |
| FR-06 | Direktori jelajah kata berdasarkan kategori (*Teknologi*, *Akademik*, *Umum*) & fitur *Word of the Day* | Sedang (P2) |
| FR-07 | Pengaturan tema tampilan (*Light Mode* & *Dark Mode*) dan instalasi PWA di Android/Desktop | Rendah (P3) |

### 2.2 Kebutuhan Nonfungsional (Nonfunctional Requirements)
- **Performa:** Waktu respons pencarian kata offline < 50 ms; ukuran aset aplikasi ringan (< 100 KB tanpa dependensi eksternal berat).
- **Ketersediaan (*Availability*):** Aplikasi tetap berjalan penuh untuk dataset offline dan UI inti meski tanpa koneksi internet berkat *Service Worker* (`sw.js`).
- **Usabilitas & Aksesibilitas:** Mendukung navigasi keyboard (`/` untuk fokus ke kolom pencarian), kontras warna tinggi, serta tata letak responsif di layar 360px hingga 1440px+.
- **Portabilitas Multi-Platform:** Dapat dijalankan di browser desktop (Windows/macOS/Linux) serta diinstal sebagai aplikasi *standalone* di Android/iOS melalui *Web App Manifest* (`manifest.json`).

### 2.3 Skenario Penggunaan Utama
1. **Pencarian Offline Cepat:** Mahasiswa mengetik `"algorithm"` -> *autocomplete* muncul -> klik/Enter -> hasil definisi, arti Indonesia, IPA, dan sinonim tampil instan tanpa internet.
2. **Pencarian Online Fallback:** Pengguna mengetik kata umum lain (misal `"serendipity"` atau `"ephemeral"` / kata baru) -> jika tidak ada di lokal, `DictionaryService` memanggil REST API `dictionaryapi.dev` -> hasil di-*cache* di memori -> ditambahkan ke riwayat.
3. **Belajar & Simpan Kata:** Pengguna mendengarkan pelafalan dengan tombol speaker, lalu menandai kata ke **Favorit** untuk dipelajari ulang.

---

## 3. Rancangan Solusi Multi-Platform

### 3.1 Target Platform & Karakteristik
- **Web Desktop (Windows / macOS / Linux):** Dimanfaatkan mahasiswa saat membaca jurnal atau coding di laptop; memanfaatkan layout 2 kolom (*Main Result Card* + *Side Panel* *Word of the Day* & Identitas) serta pintasan keyboard (`/`).
- **Android / Mobile (via PWA Standalone):** Diinstal langsung dari Chrome Android (*Add to Home Screen*) dengan tampilan *standalone* tanpa address bar, layout 1 kolom vertikal yang ramah sentuhan (*touch-friendly*).

### 3.2 Strategi Responsive & Adaptive UI
- Menggunakan **CSS Grid & Flexbox** dengan *breakpoint* `@media (max-width: 860px)` (mengubah grid 2 kolom menjadi 1 kolom) dan `@media (max-width: 600px)` (menyembunyikan elemen sekunder seperti hint keyboard agar ruang layar mobile optimal).
- Mendukung *CSS Custom Properties* (`--bg`, `--surface`, `--primary`, dll.) untuk transisi mulus antara *Light Mode* dan *Dark Mode*.

### 3.3 Wireframe Antarmuka (Desktop vs Mobile)
```text
+-------------------------------------------------------------------+
| [Aa] LexiGo           [Ammar · NIM 12231944]   [Theme Toggle]     |
+-------------------------------------------------------------------+
|              UTS Pemrograman Berbasis Platform 2                  |
|         Jelajahi Makna Kata Bahasa Inggris dengan Mudah           |
|  [  Ketik kata Bahasa Inggris...                     (/) [Cari] ] |
|  Populer: (algorithm) (serendipity) (ephemeral) (resilient)       |
+-------------------------------------------------------------------+
| [Hasil & Kamus]  [Daftar Kata]  [Favorit]  [Riwayat]              |
+---------------------------------------------+---------------------+
|  algorithm  [Teknologi] [Kamus Offline]     | Word of the Day     |
|  /ˈæl.ɡə.rɪ.ðəm/             [Audio] [Save] | serendipity         |
|  +---------------------------------------+  | /ˌser.ənˈdɪp.ə.ti/  |
|  | Arti Bahasa Indonesia                 |  | [Lihat Detail ->]   |
|  +---------------------------------------+  +---------------------+
|  noun                                       | Tentang Aplikasi    |
|  • A process or set of rules...             | Nama: Ammar         |
|  Sinonim: (procedure) (formula)             | NIM : 12231944      |
+---------------------------------------------+---------------------+
```

---

## 4. Arsitektur Sistem

### 4.1 Diagram Arsitektur Aplikasi
```mermaid
flowchart TB
    subgraph Client["Multi-Platform Client (Web Desktop & Android PWA)"]
        UI["Presentation Layer<br/>(index.html, style.css, app.js)"]
        Store["State Management Layer<br/>(state/store.js — Observer Pattern)"]
        Service["Repository / Service Layer<br/>(services/dictionaryService.js)"]
        SW["Service Worker<br/>(sw.js — Offline Asset Cache)"]
    end

    subgraph Storage["Local Persistence"]
        LocalData["Offline Dataset<br/>(dictionary.js)"]
        LocalStore["Browser Storage<br/>(localStorage: Favorit, Riwayat, Tema)"]
    end

    subgraph External["External Backend / REST API"]
        API["Free Dictionary REST API<br/>(api.dictionaryapi.dev)"]
        TTS["Web Speech API<br/>(window.speechSynthesis)"]
    end

    UI <-->|"Subscribe & Dispatch"| Store
    UI -->|"lookup(word)"| Service
    UI -->|"speak(word)"| TTS
    Store <-->|"Read / Write JSON"| LocalStore
    Service -->|"1. Cek Lokal"| LocalData
    Service -->|"2. Fallback HTTP GET (JSON)"| API
    SW -.->|"Cache App Shell"| UI
```

### 4.2 Struktur Layer Aplikasi
1. **Presentation Layer (`index.html`, `style.css`, `app.js`):** Bertanggung jawab merender DOM, menangkap input pengguna, menjalankan *Web Speech API*, dan berlangganan (*subscribe*) perubahan state.
2. **State Management Layer (`state/store.js`):** Mengelola state terpusat (`theme`, `favorites`, `history`, `currentWordEntry`, `activeTab`, `exploreCategory`) menggunakan pola **Observer** sehingga UI otomatis sinkron saat data berubah.
3. **Repository / Service Layer (`services/dictionaryService.js`):** Mengabstraksikan sumber data. Pencarian selalu memprioritaskan dataset lokal (`dictionary.js`), lalu *in-memory cache*, dan terakhir melakukan panggilan HTTP `fetch()` ke REST API eksternal.
4. **Offline & Platform Layer (`manifest.json`, `sw.js`):** Menyediakan kemampuan instalasi multi-platform (PWA) dan caching aset statis.

### 4.3 Alur Komunikasi REST API
1. Pengguna memasukkan kata dan menekan **Cari**.
2. `app.js` memanggil `DictionaryService.lookup(word)`.
3. Jika kata ditemukan di `OFFLINE_DICTIONARY`, data langsung dikembalikan tanpa jaringan.
4. Jika tidak ditemukan, `DictionaryService` mengirim `GET https://api.dictionaryapi.dev/api/v2/entries/en/{word}`.
5. Respons JSON dinormalisasi ke struktur objek internal (`word`, `phonetic`, `audioUrl`, `meanings`, `synonyms`, `antonyms`), disimpan ke `memoryCache`, lalu dirender ke UI.

---

## 5. Pemilihan Teknologi & Argumentasi Teknis

| Komponen | Teknologi yang Dipilih | Alasan Teknis Pemilihan |
|----------|------------------------|-------------------------|
| **Platform & Runtime** | HTML5, CSS3, Vanilla JavaScript (ES6+) + PWA | Zero-dependency, waktu muat sangat cepat, mudah dipelihara, dan berjalan lintas platform (Web & Android PWA) tanpa kompilasi berat. |
| **State Management** | Custom Store (`LexiStore`) berbasis *Observer Pattern* | Ringan namun terstruktur jelas memisahkan state aplikasi dari manipulasi DOM. |
| **Data & Backend API** | JSON Offline (`dictionary.js`) + `dictionaryapi.dev` REST API | Menjamin aplikasi tetap berguna 100% saat offline sekaligus memiliki cakupan kosakata bahasa Inggris yang luas saat online. |
| **Penyimpanan Lokal** | `localStorage` + `Cache API` (*Service Worker*) | Persistensi instan untuk favorit, riwayat, dan tema tanpa memerlukan setup server database eksternal. |
| **Audio Pelafalan** | `Web Speech API` (`speechSynthesis`) + Audio fallback | Tersedia secara native di browser modern desktop maupun Android tanpa library pihak ketiga. |

---

## 6. Rencana Implementasi

### 6.1 Struktur Proyek
```text
UTS_pbp2/
├── index.html                    # Entry point & semantic layout
├── style.css                     # Design system, responsive grid, light/dark theme
├── manifest.json                 # Konfigurasi PWA Multi-Platform (Web & Android)
├── sw.js                         # Service Worker untuk offline caching
├── dictionary.js                 # Dataset kosakata offline terkurasi
├── state/
│   └── store.js                  # Centralized State Management (Observer)
├── services/
│   └── dictionaryService.js      # Data repository & integrasi REST API
├── app.js                        # UI Controller & event handling
├── DOKUMEN_RANCANGAN_SOLUSI.md   # Dokumen rancangan solusi UTS
└── presentasi_uts.html           # Materi presentasi 8 slide (siap ekspor PDF)
```

### 6.2 Tahapan Pengembangan & Progres
- **Tahap 1 (Selesai — UTS):** Perancangan arsitektur 3-layer, implementasi UI responsif + *Dark Mode*, dataset offline 32 kata terkurasi, integrasi REST API `dictionaryapi.dev`, pelafalan *Web Speech API*, *Favorit & Riwayat*, serta dukungan PWA (`manifest.json` & `sw.js`).
- **Tahap 2 (Rencana Lanjutan Pasca-UTS):** Penambahan *unit testing* untuk `DictionaryService` & `LexiStore`, perluasan kosakata offline hingga 500+ kata, fitur *Quiz / Flashcard* dari daftar Favorit, serta sinkronisasi cloud opsional.

### 6.3 Kendala Teknis & Solusi
- **Kendala 1:** Kata dari API eksternal belum memiliki terjemahan Bahasa Indonesia bawaan.
  - **Solusi:** Memprioritaskan dataset lokal untuk istilah inti/akademik dengan terjemahan Bahasa Indonesia, dan menampilkan badge sumber (`Kamus Offline` vs `Online API`) secara transparan.
- **Kendala 2:** Keterbatasan koneksi internet saat menggunakan aplikasi di perangkat mobile.
  - **Solusi:** Menerapkan strategi *Offline-First* melalui `sw.js` dan `dictionary.js`.
