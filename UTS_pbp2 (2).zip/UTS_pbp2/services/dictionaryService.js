// Data & REST API Repository Layer
window.DictionaryService = (() => {
  const API_BASE = "https://api.dictionaryapi.dev/api/v2/entries/en";
  const memoryCache = new Map();

  function getAllOffline() {
    return OFFLINE_DICTIONARY;
  }

  function searchSuggestions(query, limit = 6) {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return OFFLINE_DICTIONARY.filter(
      (item) =>
        item.word.toLowerCase().includes(q) ||
        item.indonesian.toLowerCase().includes(q)
    ).slice(0, limit);
  }

  function getByCategory(category = "all") {
    const filtered =
      category === "all"
        ? OFFLINE_DICTIONARY
        : OFFLINE_DICTIONARY.filter((item) => item.category === category);
    return [...filtered].sort((a, b) => a.word.localeCompare(b.word));
  }

  function getRandomWord() {
    const idx = Math.floor(Math.random() * OFFLINE_DICTIONARY.length);
    return OFFLINE_DICTIONARY[idx];
  }

  async function lookup(rawWord) {
    const word = rawWord.trim().toLowerCase();
    if (!word) return null;

    // 1. Offline local dataset first
    const localMatch = OFFLINE_DICTIONARY.find(
      (item) => item.word.toLowerCase() === word
    );
    if (localMatch) {
      return { entry: localMatch, isOnline: false };
    }

    // 2. In-memory cache for online results
    if (memoryCache.has(word)) {
      return { entry: memoryCache.get(word), isOnline: true };
    }

    // 3. Online REST API fallback (Free Dictionary API)
    const response = await fetch(`${API_BASE}/${encodeURIComponent(word)}`);
    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    const first = data[0];
    const phoneticObj =
      (first.phonetics || []).find((p) => p.text || p.audio) || {};
    const audioObj = (first.phonetics || []).find((p) => p.audio) || {};

    const synonyms = [];
    const antonyms = [];
    (first.meanings || []).forEach((m) => {
      (m.synonyms || []).forEach((s) => {
        if (!synonyms.includes(s)) synonyms.push(s);
      });
      (m.antonyms || []).forEach((a) => {
        if (!antonyms.includes(a)) antonyms.push(a);
      });
    });

    const onlineEntry = {
      word: first.word,
      phonetic: first.phonetic || phoneticObj.text || "/.../",
      audioUrl: audioObj.audio || "",
      category: "Online",
      indonesian: "",
      meanings: (first.meanings || []).map((m) => ({
        partOfSpeech: m.partOfSpeech,
        definitions: (m.definitions || []).map((d) => ({
          definition: d.definition,
          example: d.example || ""
        }))
      })),
      synonyms,
      antonyms
    };

    memoryCache.set(word, onlineEntry);
    return { entry: onlineEntry, isOnline: true };
  }

  return {
    getAllOffline,
    searchSuggestions,
    getByCategory,
    getRandomWord,
    lookup
  };
})();
