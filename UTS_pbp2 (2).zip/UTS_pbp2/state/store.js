// Centralized State Management (Observer Pattern)
window.LexiStore = (() => {
  const STORAGE_KEYS = {
    theme: "lexigo_theme",
    favorites: "lexigo_favorites",
    history: "lexigo_history"
  };

  function loadJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch {
      return fallback;
    }
  }

  function saveJSON(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Ignore storage quota errors
    }
  }

  const state = {
    theme:
      localStorage.getItem(STORAGE_KEYS.theme) ||
      (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"),
    favorites: loadJSON(STORAGE_KEYS.favorites, []),
    history: loadJSON(STORAGE_KEYS.history, []),
    currentWordEntry: null,
    activeTab: "dictionary",
    exploreCategory: "all"
  };

  const listeners = new Set();

  function subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  }

  function notify() {
    listeners.forEach((fn) => fn(state));
  }

  function setTheme(theme) {
    state.theme = theme;
    localStorage.setItem(STORAGE_KEYS.theme, theme);
    document.documentElement.setAttribute("data-theme", theme);
    notify();
  }

  function toggleTheme() {
    setTheme(state.theme === "dark" ? "light" : "dark");
  }

  function setActiveTab(tab) {
    state.activeTab = tab;
    notify();
  }

  function setExploreCategory(cat) {
    state.exploreCategory = cat;
    notify();
  }

  function setCurrentWordEntry(entry) {
    state.currentWordEntry = entry;
    notify();
  }

  function isFavorite(word) {
    return state.favorites.some(
      (f) => f.word.toLowerCase() === String(word).toLowerCase()
    );
  }

  function toggleFavorite(entry) {
    const idx = state.favorites.findIndex(
      (f) => f.word.toLowerCase() === entry.word.toLowerCase()
    );
    let added = false;
    if (idx >= 0) {
      state.favorites.splice(idx, 1);
    } else {
      state.favorites.unshift({
        word: entry.word,
        phonetic: entry.phonetic,
        indonesian:
          entry.indonesian || (entry.meanings[0]?.definitions[0]?.definition ?? ""),
        partOfSpeech: entry.meanings[0]?.partOfSpeech || "word"
      });
      added = true;
    }
    saveJSON(STORAGE_KEYS.favorites, state.favorites);
    notify();
    return added;
  }

  function clearFavorites() {
    state.favorites = [];
    saveJSON(STORAGE_KEYS.favorites, state.favorites);
    notify();
  }

  function addHistory(entry) {
    state.history = state.history.filter(
      (h) => h.word.toLowerCase() !== entry.word.toLowerCase()
    );
    state.history.unshift({
      word: entry.word,
      phonetic: entry.phonetic,
      indonesian:
        entry.indonesian || (entry.meanings[0]?.definitions[0]?.definition ?? ""),
      partOfSpeech: entry.meanings[0]?.partOfSpeech || "word"
    });
    state.history = state.history.slice(0, 24);
    saveJSON(STORAGE_KEYS.history, state.history);
    notify();
  }

  function clearHistory() {
    state.history = [];
    saveJSON(STORAGE_KEYS.history, state.history);
    notify();
  }

  return {
    getState: () => state,
    subscribe,
    setTheme,
    toggleTheme,
    setActiveTab,
    setExploreCategory,
    setCurrentWordEntry,
    isFavorite,
    toggleFavorite,
    clearFavorites,
    addHistory,
    clearHistory
  };
})();
