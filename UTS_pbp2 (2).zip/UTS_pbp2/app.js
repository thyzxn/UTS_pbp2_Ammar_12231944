(() => {
  const store = window.LexiStore;
  const service = window.DictionaryService;

  // DOM Elements
  const searchForm = document.getElementById("searchForm");
  const searchInput = document.getElementById("searchInput");
  const clearSearchBtn = document.getElementById("clearSearch");
  const suggestionsList = document.getElementById("suggestionsList");
  const resultArea = document.getElementById("resultArea");

  const themeToggle = document.getElementById("themeToggle");
  const brandReset = document.getElementById("brandReset");
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabPanels = document.querySelectorAll(".tab-panel");

  const wotdWordEl = document.getElementById("wotdWord");
  const wotdPhoneticEl = document.getElementById("wotdPhonetic");
  const wotdMeaningEl = document.getElementById("wotdMeaning");
  const wotdOpenBtn = document.getElementById("wotdOpenBtn");
  const randomWordBtn = document.getElementById("randomWordBtn");

  const exploreGrid = document.getElementById("exploreGrid");
  const favoritesGrid = document.getElementById("favoritesGrid");
  const historyGrid = document.getElementById("historyGrid");
  const categoryFilters = document.getElementById("categoryFilters");

  const totalWordsCount = document.getElementById("totalWordsCount");
  const favCountEl = document.getElementById("favCount");
  const historyCountEl = document.getElementById("historyCount");
  const clearFavBtn = document.getElementById("clearFavBtn");
  const clearHistoryBtn = document.getElementById("clearHistoryBtn");
  const toastEl = document.getElementById("toast");

  let wotdEntry = service.getAllOffline()[1] || service.getAllOffline()[0];
  let toastTimer = null;

  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.classList.add("hidden");
    }, 2400);
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function switchTab(tabName) {
    store.setActiveTab(tabName);
    tabButtons.forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.tab === tabName);
    });
    tabPanels.forEach((panel) => {
      panel.classList.toggle("active", panel.id === `tab-${tabName}`);
    });
  }

  function speakWord(word, audioUrl) {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play().catch(() => speakWithTTS(word));
      return;
    }
    speakWithTTS(word);
  }

  function speakWithTTS(word) {
    if (!("speechSynthesis" in window)) {
      showToast("Browser tidak mendukung fitur suara.");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = "en-US";
    utterance.rate = 0.92;
    window.speechSynthesis.speak(utterance);
  }

  function renderWordResult(entry, isOnlineResult = false) {
    store.setCurrentWordEntry(entry);
    const isFav = store.isFavorite(entry.word);
    const synonyms = Array.isArray(entry.synonyms) ? entry.synonyms.slice(0, 8) : [];
    const antonyms = Array.isArray(entry.antonyms) ? entry.antonyms.slice(0, 8) : [];

    const meaningsHtml = entry.meanings
      .map(
        (m) => `
        <div class="meaning-block">
          <div class="pos-header">
            <span class="pos-badge">${escapeHtml(m.partOfSpeech)}</span>
            <span class="pos-line"></span>
          </div>
          <ul class="def-list">
            ${m.definitions
              .slice(0, 4)
              .map(
                (d) => `
              <li class="def-item">
                <p class="def-text">${escapeHtml(d.definition)}</p>
                ${d.example ? `<p class="def-example">"${escapeHtml(d.example)}"</p>` : ""}
              </li>
            `
              )
              .join("")}
          </ul>
        </div>
      `
      )
      .join("");

    const indonesianHtml = entry.indonesian
      ? `
        <div class="id-translation-box">
          <div class="id-label">Arti Bahasa Indonesia</div>
          <div class="id-meaning">${escapeHtml(entry.indonesian)}</div>
        </div>
      `
      : "";

    const synonymsHtml = synonyms.length
      ? `
        <div class="relations-row">
          <span class="rel-label">Sinonim:</span>
          ${synonyms
            .map(
              (s) =>
                `<button type="button" class="rel-pill" data-lookup="${escapeHtml(s)}">${escapeHtml(s)}</button>`
            )
            .join("")}
        </div>
      `
      : "";

    const antonymsHtml = antonyms.length
      ? `
        <div class="relations-row">
          <span class="rel-label">Antonim:</span>
          ${antonyms
            .map(
              (a) =>
                `<button type="button" class="rel-pill" data-lookup="${escapeHtml(a)}">${escapeHtml(a)}</button>`
            )
            .join("")}
        </div>
      `
      : "";

    resultArea.innerHTML = `
      <article class="card">
        <div class="word-header">
          <div class="word-title-wrap">
            <div class="word-title-row">
              <h2 class="word-title">${escapeHtml(entry.word)}</h2>
              ${entry.category ? `<span class="word-category">${escapeHtml(entry.category)}</span>` : ""}
              <span class="word-source-badge">${isOnlineResult ? "Online API" : "Kamus Offline"}</span>
            </div>
            <div class="word-phonetic">${escapeHtml(entry.phonetic || "/.../")}</div>
          </div>

          <div class="word-actions">
            <button
              type="button"
              class="action-circle"
              id="playAudioBtn"
              aria-label="Putar pelafalan kata"
              title="Dengarkan pelafalan"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
              </svg>
            </button>
            <button
              type="button"
              class="action-circle ${isFav ? "active" : ""}"
              id="toggleFavBtn"
              aria-label="Simpan ke favorit"
              title="${isFav ? "Hapus dari favorit" : "Simpan ke favorit"}"
            >
              <svg viewBox="0 0 24 24" fill="${isFav ? "currentColor" : "none"}" stroke="currentColor" stroke-width="2">
                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
              </svg>
            </button>
          </div>
        </div>

        ${indonesianHtml}
        ${meaningsHtml}
        ${synonymsHtml}
        ${antonymsHtml}
      </article>
    `;

    document.getElementById("playAudioBtn").addEventListener("click", () => {
      speakWord(entry.word, entry.audioUrl);
    });

    document.getElementById("toggleFavBtn").addEventListener("click", () => {
      const added = store.toggleFavorite(entry);
      showToast(
        added
          ? `"${entry.word}" disimpan ke favorit!`
          : `"${entry.word}" dihapus dari favorit.`
      );
    });

    resultArea.querySelectorAll("[data-lookup]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetWord = btn.dataset.lookup;
        searchInput.value = targetWord;
        updateClearBtn();
        lookupWord(targetWord);
      });
    });
  }

  function renderLoading(word) {
    resultArea.innerHTML = `
      <div class="card empty-state">
        <div class="loader"></div>
        <h3>Mencari "${escapeHtml(word)}"...</h3>
        <p>Memeriksa kamus offline &amp; basis data online.</p>
      </div>
    `;
  }

  function renderNotFound(word) {
    resultArea.innerHTML = `
      <div class="card empty-state">
        <div class="empty-icon">&#128269;</div>
        <h3>Kata "${escapeHtml(word)}" tidak ditemukan</h3>
        <p>Periksa ejaan kata Bahasa Inggris Anda atau pilih salah satu kata populer di atas.</p>
      </div>
    `;
  }

  async function lookupWord(rawWord, recordHistory = true) {
    const word = rawWord.trim().toLowerCase();
    if (!word) return;

    suggestionsList.classList.add("hidden");
    switchTab("dictionary");
    renderLoading(word);

    try {
      const result = await service.lookup(word);
      if (!result) {
        renderNotFound(word);
        return;
      }
      renderWordResult(result.entry, result.isOnline);
      if (recordHistory) {
        store.addHistory(result.entry);
      }
    } catch {
      renderNotFound(word);
    }
  }

  function renderFavorites(favorites) {
    favCountEl.textContent = favorites.length;
    clearFavBtn.classList.toggle("hidden", favorites.length === 0);

    if (favorites.length === 0) {
      favoritesGrid.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">&#128278;</div>
          <h3>Belum ada kata favorit</h3>
          <p>Klik ikon bookmark pada kartu kata untuk menyimpannya di sini.</p>
        </div>
      `;
      return;
    }

    favoritesGrid.innerHTML = favorites
      .map(
        (item) => `
        <div class="word-mini-card" data-word="${escapeHtml(item.word)}">
          <div class="mini-top">
            <span class="mini-word">${escapeHtml(item.word)}</span>
            <span class="mini-pos">${escapeHtml(item.partOfSpeech)}</span>
          </div>
          <span class="mini-phonetic">${escapeHtml(item.phonetic || "")}</span>
          <p class="mini-id">${escapeHtml(item.indonesian || "")}</p>
        </div>
      `
      )
      .join("");

    attachMiniCardListeners(favoritesGrid);
  }

  function renderHistory(history) {
    historyCountEl.textContent = history.length;
    clearHistoryBtn.classList.toggle("hidden", history.length === 0);

    if (history.length === 0) {
      historyGrid.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">&#128338;</div>
          <h3>Riwayat pencarian kosong</h3>
          <p>Kata yang Anda cari akan muncul secara otomatis di sini.</p>
        </div>
      `;
      return;
    }

    historyGrid.innerHTML = history
      .map(
        (item) => `
        <div class="word-mini-card" data-word="${escapeHtml(item.word)}">
          <div class="mini-top">
            <span class="mini-word">${escapeHtml(item.word)}</span>
            <span class="mini-pos">${escapeHtml(item.partOfSpeech)}</span>
          </div>
          <span class="mini-phonetic">${escapeHtml(item.phonetic || "")}</span>
          <p class="mini-id">${escapeHtml(item.indonesian || "")}</p>
        </div>
      `
      )
      .join("");

    attachMiniCardListeners(historyGrid);
  }

  function renderExplore(category) {
    const sorted = service.getByCategory(category);
    exploreGrid.innerHTML = sorted
      .map(
        (item) => `
        <div class="word-mini-card" data-word="${escapeHtml(item.word)}">
          <div class="mini-top">
            <span class="mini-word">${escapeHtml(item.word)}</span>
            <span class="mini-pos">${escapeHtml(item.category)}</span>
          </div>
          <span class="mini-phonetic">${escapeHtml(item.phonetic)}</span>
          <p class="mini-id">${escapeHtml(item.indonesian)}</p>
        </div>
      `
      )
      .join("");

    attachMiniCardListeners(exploreGrid);
  }

  function attachMiniCardListeners(container) {
    container.querySelectorAll(".word-mini-card").forEach((card) => {
      card.addEventListener("click", () => {
        const w = card.dataset.word;
        searchInput.value = w;
        updateClearBtn();
        lookupWord(w);
      });
    });
  }

  function setRandomWotd() {
    wotdEntry = service.getRandomWord();
    wotdWordEl.textContent = wotdEntry.word;
    wotdPhoneticEl.textContent = wotdEntry.phonetic;
    wotdMeaningEl.textContent = wotdEntry.indonesian;
  }

  function updateClearBtn() {
    clearSearchBtn.classList.toggle("hidden", searchInput.value.trim().length === 0);
  }

  function renderSuggestions(query) {
    const matches = service.searchSuggestions(query, 6);
    if (matches.length === 0) {
      suggestionsList.classList.add("hidden");
      return;
    }

    suggestionsList.innerHTML = matches
      .map(
        (m) => `
        <li class="suggestion-item" role="option" data-word="${escapeHtml(m.word)}">
          <span class="suggestion-word">${escapeHtml(m.word)}</span>
          <span class="suggestion-meaning">${escapeHtml(m.indonesian)}</span>
        </li>
      `
      )
      .join("");

    suggestionsList.classList.remove("hidden");

    suggestionsList.querySelectorAll(".suggestion-item").forEach((item) => {
      item.addEventListener("click", () => {
        const w = item.dataset.word;
        searchInput.value = w;
        updateClearBtn();
        lookupWord(w);
      });
    });
  }

  // Subscribe UI to Store updates
  store.subscribe((state) => {
    renderFavorites(state.favorites);
    renderHistory(state.history);
    if (state.currentWordEntry) {
      const btn = document.getElementById("toggleFavBtn");
      if (btn) {
        const isFav = store.isFavorite(state.currentWordEntry.word);
        btn.classList.toggle("active", isFav);
        const svg = btn.querySelector("svg");
        if (svg) svg.setAttribute("fill", isFav ? "currentColor" : "none");
      }
    }
  });

  // Event Listeners
  themeToggle.addEventListener("click", () => store.toggleTheme());

  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });

  brandReset.addEventListener("click", (e) => {
    e.preventDefault();
    switchTab("dictionary");
    lookupWord("algorithm", false);
  });

  clearFavBtn.addEventListener("click", () => {
    store.clearFavorites();
    showToast("Semua kata favorit dihapus.");
  });

  clearHistoryBtn.addEventListener("click", () => {
    store.clearHistory();
    showToast("Riwayat pencarian dibersihkan.");
  });

  categoryFilters.addEventListener("click", (e) => {
    const btn = e.target.closest(".filter-pill");
    if (!btn) return;
    const cat = btn.dataset.cat;
    store.setExploreCategory(cat);
    categoryFilters.querySelectorAll(".filter-pill").forEach((p) => {
      p.classList.toggle("active", p === btn);
    });
    renderExplore(cat);
  });

  randomWordBtn.addEventListener("click", setRandomWotd);
  wotdOpenBtn.addEventListener("click", () => {
    searchInput.value = wotdEntry.word;
    updateClearBtn();
    lookupWord(wotdEntry.word);
  });

  searchInput.addEventListener("input", () => {
    updateClearBtn();
    renderSuggestions(searchInput.value);
  });

  clearSearchBtn.addEventListener("click", () => {
    searchInput.value = "";
    updateClearBtn();
    suggestionsList.classList.add("hidden");
    searchInput.focus();
  });

  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (searchInput.value.trim()) {
      lookupWord(searchInput.value);
    }
  });

  document.querySelectorAll(".chip[data-word]").forEach((chip) => {
    chip.addEventListener("click", () => {
      const w = chip.dataset.word;
      searchInput.value = w;
      updateClearBtn();
      lookupWord(w);
    });
  });

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".search-wrapper")) {
      suggestionsList.classList.add("hidden");
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "/" && document.activeElement !== searchInput) {
      e.preventDefault();
      searchInput.focus();
    }
  });

  // Register Service Worker for Multi-Platform PWA (Web & Mobile/Android)
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("./sw.js").catch(() => {});
    });
  }

  // Initialize App
  store.setTheme(store.getState().theme);
  totalWordsCount.textContent = service.getAllOffline().length;
  renderExplore("all");
  renderFavorites(store.getState().favorites);
  renderHistory(store.getState().history);
  setRandomWotd();
  lookupWord("algorithm", false);
})();
